//
//  DeleteBookingViewController.swift
//  Assignment6
//
//  Created by karan magdani on 3/16/18.
//  Copyright © 2018 karan magdani. All rights reserved.
//

import UIKit

class DeleteBookingViewController: UIViewController {
    var index = 1;
    override func viewDidLoad() {
        super.viewDidLoad()
        print("I was called again")
        var yAxis = 0
        for booking in SingletonLists.bookList{
            let roomNameButton = UIButton(frame: CGRect(x: -5, y: 100 + yAxis, width: Int((view.frame.size.width) + 5), height: 30))
            roomNameButton.backgroundColor = .white
            //            dtf.string(from: booking.FromDate)
            roomNameButton.setTitle(booking.BookingName! , for: .normal)
            roomNameButton.setTitleColor(.black, for: .normal)
            roomNameButton.setTitleColor(.lightGray, for: .highlighted)
            roomNameButton.layer.borderWidth = 0.5
            roomNameButton.tag = index
            roomNameButton.layer.borderColor = UIColor.black.cgColor
            roomNameButton.addTarget(self, action: #selector(self.delB), for: .touchUpInside)
            index += 1;
            view.addSubview(roomNameButton)
            yAxis += 30
            
        }

        // Do any additional setup after loading the view.
    }
    
    func delB(sender:UIButton){
        //        let nameVal = window?.viewWithTag(1) as? UITextField
        print(sender.currentTitle!)
        for b in SingletonLists.bookList{
            if((sender.currentTitle!) == b.BookingName){
                let p = SingletonLists.bookList.filter { $0 !== b }
//                if let index = SingletonLists.bookList.index(of: p) {
//                    SingletonLists.bookList.remove(at: index)
//                }
                SingletonLists.bookList = p
            }
        }
        SingletonLists.createAlert(titleText: "Deleted", messageText: "Booking Deleted Successfully")
        dismiss(animated: true, completion: nil)
        
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func back(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
    func displayBookings(){
        var yAxis = 0
        var index = 1;
        for booking in SingletonLists.bookList{
            let roomNameButton = UIButton(frame: CGRect(x: -5, y: 100 + yAxis, width: Int((view.frame.size.width) + 5), height: 30))
            roomNameButton.backgroundColor = .white
            //            dtf.string(from: booking.FromDate)
            roomNameButton.setTitle(booking.BookingName! , for: .normal)
            roomNameButton.setTitleColor(.black, for: .normal)
            roomNameButton.tag = index
            roomNameButton.setTitleColor(.lightGray, for: .highlighted)
            roomNameButton.layer.borderWidth = 0.5
            roomNameButton.layer.borderColor = UIColor.black.cgColor
            index += 1;
            roomNameButton.addTarget(self, action: #selector(self.delB), for: .touchUpInside)
            view.addSubview(roomNameButton)
            yAxis += 30
            
        }
    }
    

    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
