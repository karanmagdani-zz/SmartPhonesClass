//
//  CreateBookingViewController.swift
//  Assignment6
//
//  Created by karan magdani on 3/16/18.
//  Copyright © 2018 karan magdani. All rights reserved.
//

import UIKit

class CreateBookingViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {
    @IBOutlet weak var customerPicker: UIPickerView!

    @IBOutlet weak var fromDatePicker: UIDatePicker!
    @IBOutlet weak var roomPicker: UIPickerView!
    @IBOutlet weak var toDatePicker: UIDatePicker!
    var selectedCustomer : Customer?
    var selectedRoom: Room?
    override func viewDidLoad() {
        super.viewDidLoad()
        customerPicker.dataSource = SingletonLists.customerList as? UIPickerViewDataSource
        roomPicker.dataSource = SingletonLists.roomList as? UIPickerViewDataSource
        // Do any additional setup after loading the view.
    }
    @IBAction func back(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }

    @IBAction func submit(_ sender: Any) {
        let dateTo = fromDatePicker.date
        let dateFrom = toDatePicker.date
        let daysBetweenDates = calculateDaysBetweenTwoDates(start: dateTo, end: dateFrom);
        print(daysBetweenDates)
        if(daysBetweenDates > 1){
            if(checkIfRoomAvailableForDates(start: dateFrom, end: dateTo, room: selectedRoom!)){
                let booking = Booking(selectedCustomer!, dateFrom, dateTo, selectedRoom!)
                SingletonLists.addBooking(newBooking: booking)
                SingletonLists.createAlert(titleText: "Booking Created", messageText: "Booking has been successfully created")
            }else{
                SingletonLists.createAlert(titleText: "Duplicate Booking", messageText: "There is already  a booking for these dates")
            }
        }else if(daysBetweenDates == -1){
            SingletonLists.createAlert(titleText: "Invalid Date", messageText: "You can't make a booking in the past")
        }
        else{
            SingletonLists.createAlert(titleText: "Invalid Booking", messageText: "Please Select more than one day")
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func createBookingConstructor(){
//        let dateFormatter = DateFormatter()
//        dateFormatter.dateFormat = "yyyy-MM-dd" //Your date format
//        let dateTo = dateFormatter.date(from: <#T##String#>)
//        let dateFrom = dateFormatter.date(from: dateFromStr!.text)
        
    }
    
    private func calculateDaysBetweenTwoDates(start: Date, end: Date) -> Int {
        let currentDateTime = Date()
        if(start < currentDateTime){
            return -1
        }
        let currentCalendar = Calendar.current
        //    guard is similar to if else.. it is the else part
        
        guard let start = currentCalendar.ordinality(of: .day, in: .era, for: start) else {
            return 0
        }
        guard let end = currentCalendar.ordinality(of: .day, in: .era, for: end) else {
            return 0
        }
        return end - start
    }
    
    func checkIfRoomAvailableForDates(start: Date, end: Date, room: Room) -> Bool{
        print("i am trying new booking for this room " ,room.RoomName)
        for b in SingletonLists.bookList{
            if(b.Room?.RoomName == room.RoomName){
                if(start == b.FromDate || end == b.ToDate){
                    print("We cant complete this booking as the room is unavailable for the selected days")
                    print()
                    return false;
                }
            }
        }
        print("Booking has been created successfully")
        print()
        return true;
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        if(pickerView == customerPicker){
        return SingletonLists.customerList.count
        }else{
        return SingletonLists.roomList.count
        }
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        if(pickerView == customerPicker){
            return String(describing: SingletonLists.customerList[row].Name!)
        }else{
            return String(describing: SingletonLists.roomList[row].RoomName)
        }
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        if(pickerView == customerPicker){
            selectedCustomer = SingletonLists.customerList[row]
        }else{
            selectedRoom = SingletonLists.roomList[row]
        }
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
