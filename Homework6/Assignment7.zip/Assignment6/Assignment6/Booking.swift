//
//  Booking.swift
//  Assignment4
//
//  Created by karan magdani on 2/15/18.
//  Copyright © 2018 karan magdani. All rights reserved.
//

import Foundation

class Booking{
    //     bookingName, fromDate, toDate, Customer, Room,
    static var bookingNumber = 1
    var BookingName: String?
    var FromDate: Date?
    var ToDate: Date?
    var bookNumber: Int?
    var Room: Room?
    var Customer: Customer?;
    
    init(_ Customer: Customer, _ FromDate: Date, _ ToDate: Date, _ Room: Room ){
        self.bookNumber = Booking.bookingNumber;
        self.Customer = Customer;
        Customer.IsRoomReserved = RoomReservedEnum.Reserved
        self.FromDate = FromDate;
        self.ToDate = ToDate;
        self.Room = Room;
        if(Room.RoomType == Types.DoubleOccupancy){
            if(Room.roomBooked == IsRoomBooked.Available){
                    Room.roomBooked = IsRoomBooked.OneBedBooked
            }else if(Room.roomBooked == IsRoomBooked.OneBedBooked){
                    Room.roomBooked = IsRoomBooked.Booked
            }
        }else{
            Room.roomBooked = IsRoomBooked.Booked
        }
        let BookingId: String? = String((self.Customer?.IdNumber)!)
        self.BookingName = (self.Customer?.Name)! + BookingId!
        Booking.bookingNumber += 1;
    }
}
