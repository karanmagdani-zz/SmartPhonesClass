//
//  ViewController.swift
//  Assignment6
//
//  Created by karan magdani on 3/15/18.
//  Copyright © 2018 karan magdani. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var addCustomerButton: UIButton!
    @IBOutlet weak var createRoomButton: UIButton!
    @IBOutlet weak var displayRoomButton: UIButton!
    @IBOutlet weak var createBookingButton: UIButton!
    @IBOutlet weak var displayBookingButton: UIButton!
    @IBOutlet weak var deleteBookingButton: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        let c1 = Customer("Karan", "525 Newbury", IdType.drivers_license, 5253365, 6176376750)
        let c2 = Customer("abc", "123 apple", IdType.drivers_license, 989898, 12453265235)
        let c3 = Customer("zzz", "321 orange", IdType.passport, 3544545, 43543543)
        let c4 = Customer("ccc", "777 banana", IdType.state_id, 52349010, 547547434)
        SingletonLists.addToCustomerList(newCust: c1)
        SingletonLists.addToCustomerList(newCust: c2)
        SingletonLists.addToCustomerList(newCust: c3)
        SingletonLists.addToCustomerList(newCust: c4)
        
        let r1 = Room(Types.SingleOccupancy, 500)
        let r2 = Room(Types.DoubleOccupancy, 1000)
        let r3 = Room(Types.SingleOccupancy, 500)
        let r4 = Room(Types.DoubleOccupancy, 800)
        SingletonLists.addRoom(newRoom: r1)
        SingletonLists.addRoom(newRoom: r2)
        SingletonLists.addRoom(newRoom: r3)
        SingletonLists.addRoom(newRoom: r4)
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

