//
//  persist.swift
//  Assignment4
//
//  Created by karan magdani on 2/17/18.
//  Copyright © 2018 karan magdani. All rights reserved.
//

import Foundation

class Persist: NSObject, NSCoding {
    struct Keys{
        static let RoomList = [Room]()
        static let CustomerList = [Customer]()
        static let BookingList = [Booking]()
//        var RoomList = [Room]()
//        var CustomerList = [Customer]()
//        var BookingList = [Booking]()
    }
    
    private var _RoomList = [Room]()
    private var _CustomerList = [Customer]()
    private var _BookingList = [Booking]()
    
    override init(){}
    
    init(RoomList: [Room](), CustomerList: [Customer](), BookingList: [Booking]()){
        
    }
}
