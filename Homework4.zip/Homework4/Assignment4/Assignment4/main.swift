//
//  main.swift
//  Assignment4
//
//  Created by karan magdani on 2/15/18.
//  Copyright © 2018 karan magdani. All rights reserved.
//


import Foundation

//1.	AddCustomer: Allow the user to create a new customer with the specific details.
//2.	CreateRoom: Allow user to create a room which can be booked for a customer
//    3.	DisplayRooms: Display all rooms details occupied and vacant
//4.	CreateBooking: Allow the user to create a booking for a room
//    5.	DisplayBooking: Allow the user to display all the bookings
//6. Search: Allow the user to search for a booking given a date/customer name.
//7. DeleteBooking: Delete a booking.


print("Hello, Welcome to Swift Hotels")
print("-------------------------------")
print()
//print("Here is your 'Gift?' , Go Ahead unwrap 'it!'")





var response = 0
var RoomList = [Room]()
var CustomerList = [Customer]()
var BookingList = [Booking]()

func checkResponse(){
    switch response {
    case 1:
        //1.	AddCustomer: Allow the user to create a new customer with the specific details.
        print("Please Enter the name of the customer")
        let name = readLine()
        
        print("Please enter the 🏡 address of the customer")
        let address = readLine()
        
        print("Please select from the following Id types")
        print("    1. Drivers License")
        print("    2. State ID")
        print("    3. Passport")
        let idType = readLine()
        let idTypeNum = Int(idType!)
        var idTypeEnum : IdType?
        if(idTypeNum == 1){
            idTypeEnum = IdType.drivers_license
            print("Please enter 🚗 ID number")
        }else if(idTypeNum == 2){
            idTypeEnum = IdType.state_id
            print("Please enter 🇺🇸 ID")
        }else if(idTypeNum == 3){
            idTypeEnum = IdType.passport
            print("Please Enter passport Serial number 🛂")
        }
        let licenseNumberStr = readLine()
        let licenseNumber = Int(licenseNumberStr!)
        
        print("Please enter the 📱 number of the customer")
        let phoneNumber = readLine()
        let phoneNumberInt = Int(phoneNumber!)
        
        let customer = Customer(name!, address!, idTypeEnum!, licenseNumber!, phoneNumberInt!)
        addToCustomerList(customer)
        //        print(customer.toString())
        askUser();
        break
    case 2:
        //2.	CreateRoom: Allow user to create a room which can be booked for a customer
        print("Please select the type of Room")
        print("    1. Single Occupancy")
        print("    2. Double Occupancy")
        let typeOfRoom = readLine()
        let roomTypeInt = Int(typeOfRoom!)
        var roomTypeEnum : Types?
        if(roomTypeInt == 1){
            roomTypeEnum = Types.SingleOccupancy
        }else if(roomTypeInt == 2){
            roomTypeEnum = Types.DoubleOccupancy
        }
        print("Enter the ＄ of Room")
        let price = readLine()
        let priceInt = Int(price!)
        _ = Room(roomTypeEnum!, priceInt!)
        print()
        askUser();
        break
    case 3:
        //    3.	DisplayRooms: Display all rooms details occupied and vacant
        displayRooms();
        askUser();
        break
    case 4:
        //4.	CreateBooking: Allow the user to create a booking for a room
        if(RoomList.count != 0 && CustomerList.count != 0){
            print("Please select a customer to create a booking")
            displayCustomers();
            let response = readLine()
            let customerNum = Int(response!)
            let selectedCustomer = CustomerList[customerNum! - 1]
            displayRooms()
            print("Please select a room to create a booking")
            let roomResponse = readLine()
            let roomNum = Int(roomResponse!)!
            let selectedRoom = RoomList[roomNum - 1]
            print("Please Enter From Date yyyy-MM-dd")
            let dateStr = readLine()
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "yyyy-MM-dd" //Your date format
            let date = dateFormatter.date(from: dateStr!)
            print("Please Enter To Date yyyy-MM-dd")
            let dateStr1 = readLine()
            dateFormatter.dateFormat = "yyyy-MM-dd" //Your date format
            let dateTo = dateFormatter.date(from: dateStr1!)
            let daysBetweenDates = calculateDaysBetweenTwoDates(start: date!, end: dateTo!);
            print("I am days between two dates YAY" , daysBetweenDates)
            if(daysBetweenDates > 1){
                if(checkIfRoomAvailableForDates(start: date!, end: dateTo!, room: selectedRoom)){
                    let booking = Booking(selectedCustomer, date!, dateTo!, selectedRoom)
                    addToBookingList(booking);
                }
            }else{
                print("Make a booking for atleast one day")
            }
        }else{
            print("Please create a Customer and Room First")
            print()
        }
        askUser();
        break
    case 5:
        displayBookings()
        askUser();
        break
    case 6:
        print("Do you want to search using:")
            print("1.   Date")
            print("2.   Customer Name")
        let response = readLine()
        
        let numResponse = Int(response!)
        if(numResponse == 1){
            print("please enter the starting date yyyy-MM-dd")
            let dateFormatter = DateFormatter()
            let response = readLine()
            dateFormatter.dateFormat = "yyyy-MM-dd" //Your date format
            let date = dateFormatter.date(from: response!)
            searchBookingDate(date: date!)
        }else if(numResponse == 2){
            print("please enter the name of the customer")
            let response = readLine()
            searchBooking(customer: response!)
        }
        askUser()
        break
    case 7:
        //7. DeleteBooking: Delete a booking.
        print("Please Select a booking")
        displayBookings()
        let selectedBooking = readLine()
        let selectedBookingInt = Int(selectedBooking!)
        deleteBooking(selectedBookingInt! - 1)
        askUser()
        break
    case 8:
        print("Here is your 'Gift?' , Go Ahead unwrap 'it!'")
        print("---------------------------------------------")
        print("Thank you for using the application")
        break
    default:
        print("Please enter  valid number between 1 - 7")
        print()
        askUser()
    }
}


func askUser(){
    repeat{
        print()
        print("Please Select What you want to do")
        print("---------------------------------")
        print("1. Add a Customer")
        print("2. Create a Room")
        print("3. Display Rooms")
        print("4. Create a Booking")
        print("5. Display Bookings")
        print("6. Search Booking")
        print("7. Delete a Booking")

        print("8. Exit Application")
        print("---------------------------------")
        print("---------------------------------")
        let read = readLine()
//        print("I WAS READ WTF IS THIS SHIT" , read!)
        response = Int(read!)!
 
    }while(response < 0 && response > 8)
    checkResponse();
}

func displayRooms(){
    
    
    for r in RoomList{
        print("--------------------------------------------------------")
        print("Room name " , r.RoomName , " || Occupancy " , r.RoomType! , "|| Price  ", r.Price!)
        print("--------------------------------------------------------")
        print()
    }
}

func addToRoomList(_ room: Room){
    RoomList.append(room);
    //        displayRooms();
}

func addToCustomerList(_ customer: Customer){
    CustomerList.append(customer);
}

func displayCustomers(){
    for c in CustomerList{
        print("--------------------------------------------------------")
        print(c.customerNumber!, ". Customer name ==>", c.Name! , "|| Reserved room " , c.IsRoomReserved!)
        print("--------------------------------------------------------")
        print()
    }
}

func addToBookingList(_ booking: Booking){
    BookingList.append(booking)
}

func displayBookings(){
    for b in BookingList{
        
        print("--------------------------------------------------------")
        print(b.bookNumber!, ". Booking Name ==> " ,b.BookingName! , " Room ==> " , b.Room!.RoomName , " Dates " , b.FromDate! , " -" , b.ToDate!)
        print("--------------------------------------------------------")
        print()
    }
}

func searchBooking(customer : String){
    for booking in BookingList{
        if((booking.Customer?.Name?.compare(customer)) != nil){
            print(booking.BookingName!)
        }else{
            print("no bookings found")
        }
    }
}

func searchBookingDate(date: Date){
    for booking in BookingList{
        if(booking.FromDate == date) {
            print(booking.BookingName!);
        }else{
            print("no bookings found")
        }
    }
}

func deleteBooking(_ bookingInt : Int){
    BookingList.remove(at: bookingInt)
    let room = BookingList[bookingInt].Room
    room?.roomBooked = IsRoomBooked.Available
    let customer = BookingList[bookingInt].Customer
    customer?.IsRoomReserved = RoomReservedEnum.NotReserved
    print("Removed the booking")
    print()
}

private func calculateDaysBetweenTwoDates(start: Date, end: Date) -> Int {
    
    let currentCalendar = Calendar.current
//    guard is similar to if else.. it is the else part
    guard let start = currentCalendar.ordinality(of: .day, in: .era, for: start) else {
        return 0
    }
    guard let end = currentCalendar.ordinality(of: .day, in: .era, for: end) else {
        return 0
    }
    return end - start
}

func checkIfRoomAvailableForDates(start: Date, end: Date, room: Room) -> Bool{
    print("i am trying new booking for this room " ,room.RoomName)
    for b in BookingList{
        if(b.Room?.RoomName == room.RoomName){
            if(start == b.FromDate || end == b.ToDate){
                print("We cant complete this booking as the room is unavailable for the selected days")
                print()
                return false;
            }
        }
    }
    print("Booking has been created successfully")
    print()
    return true;
}

askUser();
