//
//  main.swift
//  Homework3Commandline
//
//  Created by karan magdani on 2/11/18.
//  Copyright © 2018 karan magdani. All rights reserved.
//

import Foundation

print("please enter your name")
let response = readLine()
let number = Int(response!)
if(response == ""){
        print("Welcome Anonymous User")
} else if(number != nil){
    print("Welcome Code name \(number!)")
}else {
print("Welcome \(response!)")
}
