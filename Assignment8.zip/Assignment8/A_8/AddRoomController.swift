//
//  AddRoomController.swift
//  Assignment 6
//
//  Created by Karan Magdani on 3/3/18.
//  Copyright © 2018 Karan Magdani. All rights reserved.
//

import UIKit

class AddRoomController: UIViewController , UITextFieldDelegate, UIImagePickerControllerDelegate {
    
    @IBOutlet weak var roomPrice: UITextField!
    var dataRoom = [Room]()
    var idMax :Int32 = 0
    
    @IBOutlet weak var roomtype: UISegmentedControl!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        do{
            dataRoom = try context.fetch(Room.fetchRequest())
            
        }
        catch{
            print("ERRRRRROR")
        }
        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    @IBAction func imgPicker(_ sender: Any) {
        let nextController = UIImagePickerController()
        self.present(nextController, animated: true, completion: nil)
        
    }
    
    @IBOutlet weak var myImageView: UIImageView!
    func imagePickerController(picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : AnyObject])
        
    {
        myImageView.image = info[UIImagePickerControllerOriginalImage] as? UIImage
        
        self.dismiss(animated: true, completion: nil)
        
    }
    
    @IBAction func addRoom(_ sender: Any) {
        for element in dataRoom{
            if(idMax < element.name){ idMax = element.name}
        }
        if(roomPrice.text?.isEmpty)!{
            let alertView = UIAlertView();
            alertView.addButton(withTitle: "OK");
            alertView.title = "Information";
            alertView.message = "Please Enter a Valid Price";
            alertView.show();
        }
        else{
            switch roomtype.selectedSegmentIndex{
            case 0:
                var room: Room = Room(context : context)
                room.name = idMax + 1
                room.type = "Single"
                room.availability = "Vacant"
                room.price =  Double(roomPrice.text!)!
               appDelegate.saveContext()
                //SingetonClass.addRoom(newRoom: room)
                let alertView = UIAlertView();
                alertView.addButton(withTitle: "OK");
                alertView.title = "Information";
                alertView.message = "Room successfully created";
                alertView.show();
                break
            case 1:
                var room: Room = Room(context : context)
                room.name = idMax + 1
                 room.availability = "Vacant"
                
                room.type = "Double"
                room.price =  Double(roomPrice.text!)!
                appDelegate.saveContext()
                //SingetonClass.addRoom(newRoom: room)
                let alertView = UIAlertView();
                alertView.addButton(withTitle: "OK");
                alertView.title = "Information";
                alertView.message = "Room successfully created";
                alertView.show();
                break;
            default:
                break;
            }
        }
        
    }
    
    override  func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        //custPhone.resignFirstResponder()
        return true;
    }
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
}

