//
//  MainMenuViewController.swift
//  A_8
//
//  Created by Karan Magdani on 3/25/18.
//  Copyright © 2018 Karan Magdani. All rights reserved.
//

import UIKit

class MainMenuViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
  let list = ["Customer","Room","Booking"]
  @IBOutlet var tablleView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tablleView.delegate = self
        tablleView.dataSource = self
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
     func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }
    
     func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return list.count
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
    
     func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print(indexPath.row)
        switch indexPath.row{
        case 0: performSegue(withIdentifier: "showCustomer", sender: self)
            break
        case 1:
            performSegue(withIdentifier: "showRoom", sender: self)
            break;
        case 2:
            performSegue(withIdentifier: "showBooking", sender: self)

        default: break;
            
            
        }
    }
    
     func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tablleView.dequeueReusableCell(withIdentifier: "cell") as! CustomTableTableViewCell
        cell.crudLabel?.text = list[indexPath.row]
        cell.crudImage.image = UIImage(named: list[indexPath.row])
        // cell.cellView.layer.cornerRadius = cell.cellView.frame.height/2
        //cell.crudImage.layer.cornerRadius = cell.crudImage.frame.height/2
        return(cell)
    }
    
//     func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
//        print(indexPath.row)
//        switch indexPath.row{
//       case 0:
//            performSegue(withIdentifier: "Customer", sender: self)
//            break;
//        case 1:
//            performSegue(withIdentifier: "showAddRoom", sender: self)
//            break;
//        case 2:
//            performSegue(withIdentifier: "showDisplayRoom", sender: self)
//            
//            break;
//        case 3:
//            performSegue(withIdentifier: "showAddBooking", sender: self)
//            break;
//        case 4:
//            performSegue(withIdentifier: "showDispBookSegue", sender: self)
//            break;
//        case 5: break;
//        case 6:break;
//        case 7: break;
//        default: break;
//            
//            
//        }
//    }
    
    
 

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
