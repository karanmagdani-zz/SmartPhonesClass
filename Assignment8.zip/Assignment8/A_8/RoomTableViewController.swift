//
//  RoomTableViewController.swift
//  A_8
//
//  Created by Karan Magdani on 3/25/18.
//  Copyright © 2018 Karan Magdani. All rights reserved.
//

import UIKit

class RoomTableViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, UISearchBarDelegate {

    
    var dataRoom = [Room]()
    @IBOutlet weak var tableViewRoom: UITableView!
    @IBOutlet weak var searchRoom: UISearchBar!
    
    var fil = [String]()
    var isSearching = false
    
    var filteredData = [String]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableViewRoom.delegate = self
        tableViewRoom.dataSource = self
        searchRoom.delegate = self
        searchRoom.returnKeyType = UIReturnKeyType.done
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        print("HEYRoom")
        do {
            
            dataRoom = try context.fetch(Room.fetchRequest())
            for e in dataRoom{
                 print("1111Room")
                print(e.name)}
        }
        catch{
            print("ERROR while reading the Rooms")
        }
        tableViewRoom.reloadData()
    }
    
    
    func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if isSearching{
            return filteredData.count
        }
        
        return dataRoom.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        
        let cell = tableViewRoom.dequeueReusableCell(withIdentifier: "cellRoom", for: indexPath) as! RoomTableViewCell
        print("I came to room")
        //print(dataRoom[indexPath.row])
        
        if isSearching{
            cell.roomNo?.text = "Room No " + String(filteredData[indexPath.row])
            cell.arrow.image = UIImage(named: "arrow")
        }else{
        cell.roomNo?.text = "Room No " + String(dataRoom[indexPath.row].name)
        cell.arrow.image = UIImage(named: "arrow")
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let selectedIndex = indexPath.row
        performSegue(withIdentifier: "showRoomDetails", sender: self)
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let destination = segue.destination as? RoomDetailsViewController{
            print("11111111")
            print(dataRoom[(tableViewRoom.indexPathForSelectedRow?.row)!].name)
            destination.room = dataRoom[(tableViewRoom.indexPathForSelectedRow?.row)!]
        }
    }
    
 


    
    
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == UITableViewCellEditingStyle.delete
        {   context.delete(dataRoom[indexPath.row])
            dataRoom.remove(at: indexPath.row)
            
            appDelegate.saveContext()
            tableViewRoom.reloadData()
        }
    }
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        if  searchRoom.text == nil || searchRoom.text == ""{
           isSearching = false
            view.endEditing(true)
            tableViewRoom.reloadData()
        }
        else{
            isSearching = true
            
            for e in dataRoom {
                fil.append(String(e.name))
            }
            
            filteredData = fil.filter({$0 == searchRoom.text!})
            tableViewRoom.reloadData()
        }
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
