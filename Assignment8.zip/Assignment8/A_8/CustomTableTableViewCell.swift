//
//  CustomTableTableViewCell.swift
//  Assignment8
//
//  Created by Karan Magdani on 3/22/18.
//  Copyright © 2018 Karan Magdani. All rights reserved.
//

import UIKit

class CustomTableTableViewCell: UITableViewCell {
    
    @IBOutlet weak var cellView: UIView!
    @IBOutlet weak var crudLabel: UILabel!
    @IBOutlet weak var crudImage: UIImageView!
    //    @IBOutlet weak var crudLabel: UILabel!
//    @IBOutlet weak var crudImage: UIImageView!
//    @IBOutlet weak var cellView: UIView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
}

