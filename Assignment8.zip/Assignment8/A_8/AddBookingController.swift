//
//  AddBookingController.swift
//  Assignment7
//
//  Created by Karan Magdani on 3/19/18.
//  Copyright © 2018 Karan Magdani. All rights reserved.
//

import UIKit

class AddBookingController: UIViewController {
    
    @IBOutlet weak var custDetails: UITextView!
    @IBOutlet weak var roomtype: UISegmentedControl!
    @IBOutlet weak var toDate: UIDatePicker!
    @IBOutlet weak var fromDate: UIDatePicker!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    
    @IBOutlet weak var custID: UITextField!
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    override  func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        //custPhone.resignFirstResponder()
        return true;
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        custDetails.text = " "
        var data = [Customer]()
        do{
            data = try context.fetch(Customer.fetchRequest())
        }
        catch{
            print("ERROR While reading the Customer")
        }
        for element in data{
            print("I CAME HERE")
            custDetails.text = "\(custDetails.text!)\n Name: \(String(element.name!)) "
        }
    }
    
    var idMaxB : Int16 = 0
    @IBAction func addBooking(_ sender: UIButton) {
        var dataRoom = [Room]()
        var dataBook = [Booking]()
        do{
            dataBook = try context.fetch(Booking.fetchRequest())
        }
        catch{
            print("ERROR 3")
        }
        do{
            dataRoom = try context.fetch(Room.fetchRequest())
        }
        catch{
            print("ERROR 2")
        }
        for e in dataBook{
            if idMaxB < e.bookingName{
                idMaxB = e.bookingName
            }
        }
        if(custID.text?.isAlpha)!{
            let alertView = UIAlertView();
            alertView.addButton(withTitle: "OK");
            alertView.title = "Information";
            alertView.message = "Please Enter a Valid Customer Name";
            alertView.show();
            
        }
            
        else{
            var c : Customer?
            var t : Int = 0
            var dataCustomer = [Customer]()
            do{ dataCustomer = try context.fetch(Customer.fetchRequest())
                for  c1 in dataCustomer{
                    if c1.name == (custID?.text){
                        c = c1;
                        print("I FOUND MY CUSTOMER"+c!.name!)
                        t=1
                        break;
                    }
                }
            }
            catch{ print ("ERROR1")}
            if(t == 1){
                let calender = NSCalendar.current
                let components = calender.dateComponents([.day], from: (fromDate?.date)!, to: (toDate?.date)!)
                var y:Int = 0
                
                let noOfDays =  components.day!
                let currentDateTime = Date()
                let components1 = calender.dateComponents([.day], from:(currentDateTime) , to: (fromDate?.date)!)
                let noOfDays1 =  components1.day!
                print("c",currentDateTime)
                
                if(noOfDays1<1){
                    print("hello1",noOfDays1)
                    y = 1
                    let alertView = UIAlertView();
                    alertView.addButton(withTitle: "OK");
                    alertView.title = "Alert";
                    alertView.message = "Please Enter a Valid Date🧐";
                    alertView.show();
                }
                if (noOfDays < 1 && (noOfDays1>1) ){
                    y = 1
                    print("hello",noOfDays)
                    let alertView = UIAlertView();
                    alertView.addButton(withTitle: "OK");
                    alertView.title = "Alert";
                    alertView.message = "You can't book a room for such less time🧐";
                    alertView.show();
                }
                var booked:Int = 0;
                if(y==0){
                    switch roomtype.selectedSegmentIndex{
                    case 0:
                        var possible = 1;
                        var flagB = 0
                        
                        do{try context.fetch(Room.fetchRequest())}
                        catch {print("ERROR 2")}
                        for r in dataRoom{
                            if(r.type == "Single" && r.availability == "Occupied" )
                            { for b in dataBook{
                                print(1919191911)
                                if(r.name == b.room?.name){
                                    print("if(r.Name == b.room.Name)")
                                    print("1",(fromDate?.date.convertedDate)! )
                                    print("2",b.fromDate)
                                    print("3",(toDate?.date.convertedDate)! )
                                    print("4",b.toDate)
                                    if(!(((fromDate?.date.convertedDate)! >= b.toDate!) && ((toDate?.date.convertedDate)! >= b.toDate!) && flagB == 0)){
                                        
                                        possible = 0
                                        print(0)
                                        break
                                    }
                                }
                                
                                }
                                if(possible==1){
                                    print("po",possible)
                                    flagB = 1
                                    booked = 1
                                    let alertView = UIAlertView();
                                    alertView.addButton(withTitle: "OK");
                                    alertView.title = "Alert";
                                    alertView.message = "Booking successfully created";
                                    alertView.show();
                                    
                                    //SingetonClass.bookList.append(
                                    var b = Booking(context: context)
                                    b.fromDate = (fromDate?.date.convertedDate)!
                                    b.toDate = (toDate?.date.convertedDate)!
                                    b.customer =  c!
                                    b.room =  r
                                    b.bookingName = idMaxB + 1
                                    r.availability = "Occupied"
                                }
                                
                                
                            }
                        }
                        print("flag", flagB,"y",y,"Booked",booked)
                        if(flagB == 0 && y == 0){
                            for r in dataRoom
                            {
                                if r.availability == "Vacant" && r.type == "Single"{
                                    let b1 : Booking = Booking(context : context)
                                    b1.fromDate =  (fromDate?.date.convertedDate)!
                                    b1.toDate = (toDate?.date.convertedDate)!
                                    b1.customer = c!
                                    b1.bookingName = idMaxB + 1
                                    b1.room = r
                                    
                                    r.availability = "Occupied"
                                    print("Room",r.type)
                                    let alertView = UIAlertView();
                                    alertView.addButton(withTitle: "OK");
                                    alertView.title = "Alert";
                                    alertView.message = "OYE";
                                    alertView.show();
                                    booked = 1
                                    
                                    print("flag=0")
                                    break
                                }
                            }
                        }
                        
                        if(booked == 0 ){
                            let alertView = UIAlertView();
                            alertView.addButton(withTitle: "OK");
                            alertView.title = "Alert";
                            alertView.message = "NO Booking created";
                            alertView.show();
                        }
                        
                        break
                    case 1:
                        var possible = 1;
                        var flagB = 0
                        for r in dataRoom{
                            if(r.type == "Double" && r.availability == "Occupied" )
                            { for b in dataBook{
                                if(r.name == b.room?.name){
                                    print("if(r.Name == b.room.Name)")
                                    print("1",(fromDate?.date.convertedDate)! )
                                    print("2",b.fromDate)
                                    print("3",(toDate?.date.convertedDate)! )
                                    print("4",b.toDate)
                                    if(!(((fromDate?.date)! >= b.toDate!) && ((toDate?.date)! >= b.toDate!) && flagB == 0)){
                                        
                                        possible = 0
                                        print(0)
                                        break
                                    }
                                }
                                
                                }
                                if(possible==1){
                                    print("po",possible)
                                    flagB = 1
                                    booked = 1
                                    let alertView = UIAlertView();
                                    alertView.addButton(withTitle: "OK");
                                    alertView.title = "Alert";
                                    alertView.message = "Booking successfully created";
                                    alertView.show();
                                    
                                    
                                    var b3 = Booking(context : context)
                                    b3.fromDate =  (fromDate?.date.convertedDate)!
                                    b3.toDate = (toDate?.date.convertedDate)!
                                    b3.customer =  c!
                                    b3.bookingName = idMaxB + 1
                                    b3.room = r
                                    r.availability = "Occupied"
                                }
                                
                                
                            }
                        }
                        print("flag", flagB,"y",y,"Booked",booked)
                        if(flagB == 0 && y == 0){
                            for r in dataRoom
                            {
                                if r.availability == "Vacant" && r.type == "Double"{
                                    let b1 =  Booking(context : context)
                                    b1.fromDate = (fromDate?.date.convertedDate)!
                                    b1.toDate =  (toDate?.date.convertedDate)!
                                    b1.customer = c!
                                    b1.room = r
                                    b1.bookingName = idMaxB + 1
                                    r.availability = "Occupied"
                                    print("Room",r.type)
                                    let alertView = UIAlertView();
                                    alertView.addButton(withTitle: "OK");
                                    alertView.title = "Alert";
                                    alertView.message = "Successfully Created";
                                    alertView.show();
                                    booked = 1
                                    
                                    print("flag=0")
                                    break
                                }
                            }
                        }
                        
                        if(booked == 0 ){
                            let alertView = UIAlertView();
                            alertView.addButton(withTitle: "OK");
                            alertView.title = "Alert";
                            alertView.message = "NO Booking created";
                            alertView.show();
                        }
                        
                        
                        break
                    default:
                        break
                    }
                }
                
            }
            else{
                let alertView = UIAlertView();
                alertView.addButton(withTitle: "OK");
                alertView.title = "Alert";
                alertView.message = "No Customer with Name";
                alertView.show();
            }
            
            
        }
        appDelegate.saveContext()
    }
}
extension Date {
    
    var convertedDate:Date {
        
        let dateFormatter = DateFormatter();
        
        let dateFormat = "dd MMM yyyy";
        dateFormatter.dateFormat = dateFormat;
        let formattedDate = dateFormatter.string(from: self);
        
        dateFormatter.locale = NSLocale.current;
        dateFormatter.timeZone = TimeZone(abbreviation: "GMT+0:00");
        
        dateFormatter.dateFormat = dateFormat as String;
        let sourceDate = dateFormatter.date(from: formattedDate as String);
        
        return sourceDate!;
    }
}


