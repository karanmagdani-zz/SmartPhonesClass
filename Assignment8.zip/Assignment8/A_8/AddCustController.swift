//
//  AddCustController.swift
//  Assignment 6
//
//  Created by Karan Magdani on 3/3/18.
//  Copyright © 2018 Karan Magdani. All rights reserved.
//

import UIKit

class AddCustController: UIViewController, UITextFieldDelegate {
    
    @IBOutlet weak var custName: UITextField!
    @IBOutlet weak var custAddr: UITextField!
    
    @IBOutlet weak var custID: UITextField!
    
    @IBOutlet weak var custPhone: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        var data = [Customer]()
        do{
            data = try context.fetch(Customer.fetchRequest())
        }
        catch{
            print("ERROR While reading the Customer")
        }
//        for element in data{
//            print("I CAME HERE"+element.name!)
//         
//        }
        self.custPhone.delegate = self
        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func back(_ sender: Any) {
        self.modalTransitionStyle = UIModalTransitionStyle.coverVertical
        
        dismiss(animated: true, completion: nil)
    }
    
    func validate(value: String) -> Bool {
        let PHONE_REGEX = "^\\d{10}$"
        let phoneTest = NSPredicate(format: "SELF MATCHES %@", PHONE_REGEX)
        let result =  phoneTest.evaluate(with: value)
        
        return result
    }
    
    @IBAction func AddCustomer(_ sender: UIButton) {
        print("HELLO")
        let val = self.validate(value: (custPhone?.text)!)
        if(custName.text?.isAlpha)!{
            let alertView = UIAlertView();
            alertView.addButton(withTitle: "OK");
            alertView.title = "Information";
            alertView.message = "Please enter a Valid Name";
            alertView.show();
        }
            
        else if(custID.text?.isEmpty)!{
            let alertView = UIAlertView();
            alertView.addButton(withTitle: "OK");
            alertView.title = "Information";
            alertView.message = "Please enter a Valid Passport ID";
            alertView.show();
        }
        else if(custAddr.text?.isEmpty)!{
            let alertView = UIAlertView();
            alertView.addButton(withTitle: "OK");
            alertView.title = "Information";
            alertView.message = "Please enter a Address";
            alertView.show();
        }
//        else if(val == false){
//            let alertView = UIAlertView();
//            alertView.addButton(withTitle: "OK");
//            alertView.title = "Alert";
//            alertView.message = "Enter correct phone number";
//            alertView.show();
//        }
        else{
            var c : Customer = Customer(context : context)
            c.name = custName.text!
            c.address = custAddr.text!
            c.idNumber =  custID.text!
            c.phoneNumber = Int64(custPhone.text!)!;
            appDelegate.saveContext()
            //SingetonClass.addCustomer(newCust: c)
   
            let alertView = UIAlertView();
            alertView.addButton(withTitle: "OK");
            alertView.title = "Information";
            alertView.message = "Customer successfully created";
            alertView.show();
        }
        
    }
    
    override  func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        //custPhone.resignFirstResponder()
        return true;
    }
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
}
extension String {
    var isAlpha: Bool {
        return isEmpty ||
            range(of: "[^0-9-/:;()$&@\".,?!']", options: .regularExpression) == nil
    }
}

