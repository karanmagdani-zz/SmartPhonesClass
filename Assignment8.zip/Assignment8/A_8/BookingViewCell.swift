//
//  BookingViewCell.swift
//  A_8
//
//  Created by Karan Magdani on 3/25/18.
//  Copyright © 2018 Karan Magdani. All rights reserved.
//

import UIKit

class BookingViewCell: UITableViewCell {
    @IBOutlet weak var bookingName: UILabel!
    @IBOutlet weak var arrow: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
